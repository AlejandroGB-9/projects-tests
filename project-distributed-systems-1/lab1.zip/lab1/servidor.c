/*standard libraries*/

#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include <pthread.h>

#include "servidor.h"

#define MAX_CHAIN 255 //tamaño maximo de la cadena

struct nodo *head = NULL;
struct nodo *aux = NULL;
struct nodo *aux2 = NULL;

pthread_mutex_t read_mutex;
pthread_mutex_t source_mutex;
int n_readers = 0;
pthread_cond_t read_cond; 

struct nodo
{
    int key;
    int key2;
    char value1[MAX_CHAIN];    
    int value2; //valor 2
    double value3; //valor 3
    struct nodo *next;
};

int save_request(int key, int key2, char *value1, int value2, double value3)
{

    aux = (struct nodo*)malloc(sizeof(struct nodo));
    aux->key = key;
    aux->key2 = key2;
    strcpy(aux->value1, value1);
    aux->value2 = value2;
    aux->value3 = value3;
    aux->next = NULL;


    if (head == NULL){
        
        head = (struct nodo*)malloc(sizeof(struct nodo));
        head = aux;

    } else {

        aux2 = head;
        while (aux2->next != NULL)
        {
                aux2 = aux2->next;
        }
        aux2->next = aux;

    }
    return TRUE;
}

int real_init()
{

    pthread_mutex_lock(&source_mutex);
    while(head->next != NULL){
        aux = head;
        head = head->next;
        free(aux);
    }
    
    free(head);
    pthread_mutex_unlock(&source_mutex);
    return 0;

}

int real_set_value(int key, char *value1, int value2, double value3)
{
/*Este servicio inserta el elemento <key, value1, value2, value3>. El servicio devuelve 0 si se
insertó con éxito y -1 en caso de error. Se considera error, intentar insertar una clave que ya
existe previamente. En este caso se devolverá -1 y no se insertará. También se considerará error
cualquier error en las comunicaciones.*/
        pthread_mutex_lock(&source_mutex);
        struct nodo *aux3;
        if (real_exist(key) == 0){
                return -1;
        }
        aux3 = (struct nodo*)malloc(sizeof(struct nodo));
        aux3->key = key;
        strcpy(aux3->value1, value1);
        aux3->value2 = value2;
        aux3->value3 = value3;
        aux3->next = NULL;
        aux2->next = aux;
        pthread_mutex_lock(&source_mutex);
        return 0;

}

int real_get_value(int key, char *value1, int *value2, double *value3) 
{
        /*Este servicio permite obtener los valores asociados a la clave key. Los valores se devuelven en
        value1, value2 y value3. La función devuelve 0 en caso de éxito y -1 en caso de error, por
        ejemplo, si no existe un elemento con dicha clave o si se produce un error de comunicaciones*/

        pthread_mutex_lock(&read_mutex);
        n_readers++;
        int th_id;
        if (n_readers == 1){
                th_id = pthread_self();
                pthread_mutex_lock(&source_mutex);
        }
        pthread_mutex_unlock(&read_mutex);
        struct nodo *aux3;
        int *res;
        res = buscar_key(key);
        aux3 = *res;
        if (res != NULL){ 
                strcpy(value1, aux3->value1);
                *value2 = aux3->value2;
                *value3 = aux3->value3;
                pthread_mutex_lock(&read_mutex);
                n_readers--;
                if (th_id == pthread_self()){
                        while (n_readers > 0){
                                pthread_cond_wait(&read_cond, &read_mutex);
                        }
                        pthread_mutex_unlock(&source_mutex);
                
                } else {
                        pthread_cond_signal(&read_cond);
                }
                pthread_mutex_unlock(&read_mutex);
                return 0;
        }
        pthread_mutex_lock(&read_mutex);
        n_readers--;
        if (th_id == pthread_self()){
                while (n_readers > 0){
                        pthread_cond_wait(&read_cond, &read_mutex);
                }
                pthread_mutex_unlock(&source_mutex);
        
        } else {
                pthread_cond_signal(&read_cond);
        }
        pthread_mutex_unlock(&read_mutex);
        return -1;


}

int real_modify_value(int key, char *value1, int value2, double value3)
{
/*Este servicio permite modificar los valores asociados a la clave key. La función devuelve 0 en caso de
éxito y -1 en caso de error, por ejemplo, si no existe un elemento con dicha clave o si se produce
un error en las comunicaciones.*/

        pthread_mutex_lock(&source_mutex);
        struct nodo *aux3;
        int *res;
        res = buscar_key(key);
        aux3 = *res;
        if( res != NULL){
                strcpy(aux3->value1, value1);
                aux3->value2 = value2;
                aux3->value3 = value3;
                pthread_mutex_unlock(&source_mutex);
                return 0;
        }
        pthread_mutex_unlock(&source_mutex);
        return -1;
}

int real_delete_key(int key)
{

/*Este servicio permite borrar el elemento cuya clave es key. La
función devuelve 0 en caso de éxito y -1 en caso de error. En caso de que la clave no exista
también se devuelve -1.*/
        pthread_mutex_lock(&source_mutex);
        struct nodo *aux3;
        struct nodo *aux4;
        int res;
        res = real_exist(key);
        if( res == 0){
               aux3 = head;
               while(aux3->next != NULL){
                        if(aux3->next->key == key){
                                aux4 = aux3; /*previous*/
                                aux3=aux3->next; /*actual*/
                                aux4->next = aux3->next;
                                free(aux3);
                                break;
                        }

                        aux3 = aux3->next;
                }
                pthread_mutex_unlock(&source_mutex);
                return 0;
        }
        pthread_mutex_unlock(&source_mutex);
        return -1;

}

int real_exist(int key)
{
        
/*Este servicio permite determinar si existe un elemento con clave key.
La función devuelve 1 en caso de que exista y 0 en caso de que no exista. En caso de error se
devuelve -1. Un error puede ocurrir en este caso por un problema en las comunicaciones*/
        
        pthread_mutex_lock(&read_mutex);
        n_readers++;
        int th_id;
        if (n_readers == 1){
                th_id = pthread_self();
                pthread_mutex_lock(&source_mutex);
        }
        pthread_mutex_unlock(&read_mutex);
        struct nodo *aux3;
        aux3 = head;
        while(aux3->next != NULL){
                if(aux3->key == key){
                pthread_mutex_lock(&read_mutex);
                n_readers--;
                if ( th_id == pthread_self()){
                        while (n_readers > 0){
                                pthread_cond_wait(&read_cond, &read_mutex);
                        }
                        pthread_mutex_unlock(&source_mutex);
                
                } else {
                        pthread_cond_signal(&read_cond);
                }
                pthread_mutex_unlock(&read_mutex);
                return 0;
                }
                aux3 = aux3->next;
        }
        if(aux3->key == key){
                pthread_mutex_lock(&read_mutex);
                n_readers--;
                if ( th_id == pthread_self()){
                        while (n_readers > 0){
                                pthread_cond_wait(&read_cond, &read_mutex);
                        }
                        pthread_mutex_unlock(&source_mutex);
                
                } else {
                        pthread_cond_signal(&read_cond);
                }
                pthread_mutex_unlock(&read_mutex);
                return 0;
        }
        pthread_mutex_lock(&read_mutex);
        n_readers--;
        if ( th_id == pthread_self()){
                while (n_readers > 0){
                        pthread_cond_wait(&read_cond, &read_mutex);
                }
                pthread_mutex_unlock(&source_mutex);
        
        } else {
                pthread_cond_signal(&read_cond);
        }
        pthread_mutex_unlock(&read_mutex);
        return -1;
}

int real_copy_key(int key1, int key2)
{

/*Este servicio crea e inserta una nueva clave (key2)
copiando los valores de la clave key1 en la nueva clave creada (key2). En caso de que key1 no
exista se devolverá -1 y no se creará la nueva clave. Si la clave key2 no existe, se creará y se
copiarán los valores de key1 en key2. En caso de que la clave key2 exista, se modificarán sus
valores a partir de los de key1. La función devuelve 0 en caso de poder crear y copiar los nuevos
datos en key2 y -1 en cualquier otro caso.*/
    pthread_mutex_lock(&source_mutex);
    struct nodo *aux3;
    struct nodo *aux4;
    int *res;
    res = buscar_key(key1);
    aux3 = *res;
    if(res != NULL){
        aux4 = aux3;
    }
    res = buscar_key(key2);
    aux3 = *res;
    if(res != NULL){
        strcpy(aux3->value1, aux4->value1);
        aux3->value2 = aux4->value2;
        aux3->value3 = aux4->value3;
        pthread_mutex_unlock(&source_mutex);
        return 0;
    }
    pthread_mutex_unlock(&source_mutex);
    return -1;


}

int buscar_key(int key){

        pthread_mutex_lock(&read_mutex);
        n_readers++;
        int th_id;
        if (n_readers == 1){
                th_id = pthread_self();
                pthread_mutex_lock(&source_mutex);
        }
        pthread_mutex_unlock(&read_mutex);
        struct nodo *aux3;
        aux3 = head;
        int *res;
        while(aux3->next != NULL){
                if(aux3->key == key){
                pthread_mutex_lock(&read_mutex);
                n_readers--;
                if ( th_id == pthread_self()){
                        while (n_readers > 0){
                                pthread_cond_wait(&read_cond, &read_mutex);
                        }
                        pthread_mutex_unlock(&source_mutex);
                
                } else {
                        pthread_cond_signal(&read_cond);
                }
                pthread_mutex_unlock(&read_mutex);
                pthread_mutex_lock(&read_mutex);
                n_readers--;
                if (th_id == pthread_self()){
                        while (n_readers > 0){
                                pthread_cond_wait(&read_cond, &read_mutex);
                        }
                        pthread_mutex_unlock(&source_mutex);
                
                } else {
                        pthread_cond_signal(&read_cond);
                }
                pthread_mutex_unlock(&read_mutex);
                res = &(aux3);
                return res;
                }
                aux3 = aux3->next;
        }
        if(aux3->key == key){
                pthread_mutex_lock(&read_mutex);
                n_readers--;
                if (th_id == pthread_self()){
                        while (n_readers > 0){
                                pthread_cond_wait(&read_cond, &read_mutex);
                        }
                        pthread_mutex_unlock(&source_mutex);
                
                } else {
                        pthread_cond_signal(&read_cond);
                }
                pthread_mutex_unlock(&read_mutex);
                res = &(aux3);
                return res;
        }

        pthread_mutex_lock(&read_mutex);
        n_readers--;
        if (th_id == pthread_self()){
                while (n_readers > 0){
                        pthread_cond_wait(&read_cond, &read_mutex);
                }
                pthread_mutex_unlock(&source_mutex);
        
        } else {
                pthread_cond_signal(&read_cond);
        }
        pthread_mutex_unlock(&read_mutex);
        res = NULL;
        return res;

}
