/*libraries for queues*/

#include<fcntl.h>
#include<sys/stat.h>
#include<mqueue.h>

/*standard libraries*/

#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include"claves.h"
#include<unistd.h> 

mqd_t q_server;
mqd_t q_client;

#define MAX_CHAIN 255 //tamaño maximo de la cadena
#define MAX_QUEUE 1024 //tamaño maximo de la cola

struct peticion
{
    int op; //valor de la operacion para el switch case 
    int key; //clave
    int key2; //clave 2 para copykey
    char value1[MAX_CHAIN]; //valor 1
    int value2; //valor 2
    double value3; //valor 3
    char q_name[MAX_QUEUE]; //nombre de la cola
};

struct respuesta
{
    char value1[MAX_CHAIN]; //valor de la respuesta
    int value2; //valor 2
    double value3; //valor 3
    int status; //estado de la respuesta
};
struct mq_attr q_attr = {
    .mq_flags = 0,
    .mq_maxmsg = 10,
    .mq_msgsize = sizeof(struct peticion),
    .mq_curmsgs = 0
};

int init()
{

    struct peticion p;
    struct respuesta r;
    char q_name[MAX_QUEUE];

    sprintf(q_name, "%s%d", "/client_", getpid());
    q_server = mq_open("/server", O_WRONLY, &q_attr);
    if (q_server == -1)
    {
        perror("Error al abrir la cola del servidor");
        exit(-1);
    }
    q_client = mq_open(q_name, O_CREAT | O_RDONLY, &q_attr);
    if (q_client == -1)
    {
        perror("Error al abrir la cola del cliente");
        exit(-1);
    }
    strcpy(p.q_name, q_name);
    p.op = 0;
    mq_send (q_server, (char *)&p, sizeof(p), 0);
    mq_receive(q_client, (char *)&r, sizeof(r), 0);
    mq_close(q_server);
    mq_close(q_client);
    mq_unlink(q_name);
    return r.status;

}

int set_value(int key, char *value1, int value2, double value3)
{

    struct peticion p;
    struct respuesta r;
    char q_name[MAX_QUEUE];

    sprintf(q_name, "%s%d", "/client_", getpid());
    q_server = mq_open("/server", O_WRONLY, &q_attr);
    if (q_server == -1)
    {
        perror("Error al abrir la cola del servidor");
        exit(-1);
    }
    q_client = mq_open(q_name, O_CREAT | O_RDONLY, &q_attr);
    if (q_client == -1)
    {
        perror("Error al abrir la cola del cliente");
        exit(-1);
    }
    strcpy(p.q_name, q_name);
    p.op = 1;
    p.key = key;
    strcpy(p.value1, value1);
    p.value2 = value2;
    p.value3 = value3;
    mq_send (q_server, (char *)&p, sizeof(p), 0);
    mq_receive(q_client, (char *)&r, sizeof(r), 0);
    mq_close(q_server);
    mq_close(q_client);
    mq_unlink(q_name);
    return r.status;
}
int get_value(int key, char *value1, int *value2, double *value3)
{
    
    struct peticion p;
    struct respuesta r;
    char q_name[MAX_QUEUE];

    sprintf(q_name,"%s%d","/client_",getpid());
    q_server=mq_open("/server", O_WRONLY, &q_attr);
     if (q_server == -1)
    {
        perror("Error al abrir la cola del cliente");
        exit(-1);
    }
    q_client = mq_open(q_name, O_CREAT | O_RDONLY, &q_attr);
    if (q_client == -1)
    {
        perror("Error al abrir la cola del cliente");
        exit(-1);
    }
    strcpy(p.q_name,q_name);
    p.op = 2;
    p.key = key;
    mq_send (q_server, (char *)&p, sizeof(p), 0);
    mq_receive(q_client, (char *)&r, sizeof(r), 0);
    mq_close(q_server);
    mq_close(q_client);
    mq_unlink(q_name);
    strcpy(value1, r.value1); 
    *value2 = r.value2;
    *value3 = r.value3;
    printf("Value1: %s, Value2: %d, Value3: %f", r.value1, r.value2, r.value3);
    return r.status;
    
}
int modify_value(int key, char *value1, int value2, double value3)
{

    struct peticion p;
    struct respuesta r;
    char q_name[MAX_QUEUE];

    sprintf(q_name, "%s%d", "/client_", getpid());
    q_server = mq_open("/server",  O_WRONLY, &q_attr);
    if (q_server == -1)
    {
        perror("Error al abrir la cola del servidor");
        exit(-1);
    }
    q_client = mq_open(q_name, O_CREAT | O_RDONLY, &q_attr);
    if (q_client == -1)
    {
        perror("Error al abrir la cola del cliente");
        exit(-1);
    }
    strcpy(p.q_name, q_name);
    p.op = 3;
    p.key = key;
    strcpy(p.value1, value1);
    p.value2 = value2;
    p.value3 = value3;
    mq_send (q_server, (char *)&p, sizeof(p), 0);
    mq_receive(q_client, (char *)&r, sizeof(r), 0);
    mq_close(q_server);
    mq_close(q_client);
    mq_unlink(q_name);
    return r.status;
} 
int delete_key(int key)
{

    struct peticion p;
    struct respuesta r;
    char q_name[MAX_QUEUE];

    sprintf(q_name, "%s%d", "/client_", getpid());
    q_server = mq_open("/server", O_WRONLY, &q_attr);
    if (q_server == -1)
    {
        perror("Error al abrir la cola del servidor");
        exit(-1);
    }
    q_client = mq_open(q_name, O_CREAT | O_RDONLY, &q_attr);
    if (q_client == -1)
    {
        perror("Error al abrir la cola del cliente");
        exit(-1);
    }
    strcpy(p.q_name, q_name);
    p.op = 4;
    p.key = key;
    mq_send (q_server, (char *)&p, sizeof(p), 0);
    mq_receive(q_client, (char *)&r, sizeof(r), 0);
    mq_close(q_server);
    mq_close(q_client);
    mq_unlink(q_name);
    return r.status;
}
int exist(int key)
{

    struct peticion p;
    struct respuesta r;
    char q_name[MAX_QUEUE];

    sprintf(q_name, "%s%d", "/client_", getpid());
    q_server = mq_open("/server", O_WRONLY, &q_attr);
    if (q_server == -1)
    {
        perror("Error al abrir la cola del servidor");
        exit(-1);
    }
    q_client = mq_open(q_name, O_CREAT | O_RDONLY, &q_attr);
    if (q_client == -1)
    {
        perror("Error al abrir la cola del cliente");
        exit(-1);
    }
    strcpy(p.q_name, q_name);
    p.op = 5;
    p.key = key;
    mq_send (q_server, (char *)&p, sizeof(p), 0);
    mq_receive(q_client, (char *)&r, sizeof(r), 0);
    mq_close(q_server);
    mq_close(q_client);
    mq_unlink(q_name);
    return r.status;
}
int copy_key(int key1, int key2)
{

    struct peticion p;
    struct respuesta r;
    char q_name[MAX_QUEUE];

    sprintf(q_name, "%s%d", "/client_", getpid());
    q_server = mq_open("/server", O_WRONLY, &q_attr);
    if (q_server == -1)
    {
        perror("Error al abrir la cola del servidor");
        exit(-1);
    }
    q_client = mq_open(q_name, O_CREAT | O_RDONLY, &q_attr);
    if (q_client == -1)
    {
        perror("Error al abrir la cola del cliente");
        exit(-1);
    }
    strcpy(p.q_name, q_name);
    p.op = 6;
    p.key = key1;
    p.key2 = key2;
    mq_send (q_server, (char *)&p, sizeof(p), 0);
    mq_receive(q_client, (char *)&r, sizeof(r), 0);
    mq_close(q_server);
    mq_close(q_client);
    mq_unlink(q_name);
    return r.status;
}