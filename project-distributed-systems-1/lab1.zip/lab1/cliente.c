/*standard libraries*/

#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include"claves.h"

#define MAX_CHAIN 255 //tamaño maximo de la cadena

int main(void)
{

    int key, key2, value2, op, result;
    double value3;
    char value1[MAX_CHAIN];
    /* peticion de datos: */
    printf("Seleccione el número de operación que desea realizar: \n\t0. Init\n\t1. Set Value\n\t2. Get Value\n\t3. Modify Value\n\t4. Delete Key\n\t5. Exist\n\t6. Copy Key\n");
    scanf("%d",&op);
    while (op < 0 || op > 6)
    {
        printf("Número de operacion no valido\n");
        printf("Seleccione el número de operación que desea realizar: \n\t0. Init\n\t1. Set Value\n\t2. Get Value\n\t3. Modify Value\n\t4. Delete Key\n\t5. Exist\n\t6. Copy Key\n");
        scanf("%d",&op);
    }

    switch(op){

        case 0:
            printf("Ha seleccionado la operación Init\n");
            result = init();
            break;
        case 1:
            printf("Ha seleccionado la operación Set Value\n");
            printf("Introduzca el valor de la clave: ");
            scanf("%d",&key);
            printf("Introduzca el valor del primer campo: ");
            scanf("%s", value1);
            printf("Introduzca el valor del segundo campo: ");
            scanf("%d",&value2);
            printf("Introduzca el valor del tercer campo: ");
            scanf("%lf",&value3);
            result = set_value(key, value1, value2, value3);
            break;
        case 2:
            printf("Ha seleccionado la operación Get Value\n");
            printf("Introduzca el valor de la clave: ");
            scanf("%d",&key);
            result = get_value(key, value1, &value2, &value3);
            break;
        case 3:
            printf("Ha seleccionado la operación Modify Value\n");
            printf("Introduzca el valor de la clave: ");
            scanf("%d",&key);
            printf("Introduzca el valor del primer campo: ");
            scanf("%s", value1);
            printf("Introduzca el valor del segundo campo: ");
            scanf("%d",&value2);
            printf("Introduzca el valor del tercer campo: ");
            scanf("%le",&value3);
            result = modify_value(key, value1, value2, value3);
            break;
        case 4:
            printf("Ha seleccionado la operación Delete Key\n");
            printf("Introduzca el valor de la clave: ");
            scanf("%d",&key);
            result = delete_key(key);
            break;
        case 5:
            printf("Ha seleccionado la operación Exist\n");
            printf("Introduzca el valor de la clave: ");
            scanf("%d",&key);
            result = exist(key);
            break;
        case 6:
            printf("Ha seleccionado la operación Copy Key\n");
            printf("Introduzca el valor de la clave: ");
            scanf("%d",&key);
            printf("Introduzca el valor de la clave a copiar: ");
            scanf("%d",&key2);
            result = copy_key(key, key2);
            break;
    }

    return result;

}