server = proxy
client = claves

no tocar xdr,svr ni clnt

en los bool llamar a las funciones de server

hacer get y rellenar la struct


