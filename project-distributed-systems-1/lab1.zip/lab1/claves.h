#ifndef CLAVES_H
#define CLAVES_H

int init();
int set_value(int key, char *value1, int value2, double value3);
int get_value(int key, char *value1, int *value2, double *value3);
int modify_value(int key, char *value1, int value2, double value3);
int delete_key(int key);
int exist(int key);
int copy_key(int key1, int key2);

#endif

//las funciones se incluyen aquí, su definición
// lo que se pone son las llamadas a dichas funciones    luego en el .c añadir:         #include "claves.h"
// crear un     gcc -0 math.o math.c -c     en la terminal
// ld -o libreria.so math.o -shared
