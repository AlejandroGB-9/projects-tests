# Ej-1-Distributed-systems
https://youtu.be/TFbqYAr8xYI
https://youtu.be/7Fz7JSvlr9g
https://youtu.be/DneLxrPmmsw
